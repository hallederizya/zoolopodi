// scripts/add_media.ts
import * as path from "path";
import { config } from "dotenv";
import { createClient } from "@supabase/supabase-js";

// .env.local dosyasını yükle
config({ path: path.join(__dirname, '..', '.env.local') });

// Ortam değişkenlerini al (env.local'daki değerleri kullanır)
const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE!   // yazma için service_role kullan
);

async function main() {
  const taxonId = 1; // Eklemek istediğin türün id'si (örneğin Panthera pardus)
  
  const mediaItem = {
    taxon_id: taxonId,
    kind: "image",
    url: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Panthera_pardus_close_up.jpg/250px-Panthera_pardus_close_up.jpg",
    thumb_url: "https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Panthera_pardus_close_up.jpg/150px-Panthera_pardus_close_up.jpg",
    title: "Panthera pardus close up",
    author: "Charles J. Sharp",
    license: "CC BY-SA 4.0",
    source: "Wikimedia Commons",
  };

  const { data, error } = await supabase
    .from("media")
    .insert(mediaItem)
    .select();

  if (error) {
    console.error("Ekleme hatası:", error);
  } else {
    console.log("Medya eklendi:", data);
  }
}

main();
