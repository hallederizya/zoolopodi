import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
);

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = (searchParams.get("q") || "").trim();
  if (!q) return NextResponse.json([]);

  // ortak ad veya bilimsel addan ara
  const { data, error } = await supabase
    .from("taxon_name")
    .select("taxon_id, name, lang, is_scientific, taxon:taxon_id(canonical_name, rank)")
    .ilike("name", `%${q}%`)
    .limit(10);

  if (error) return NextResponse.json([], { status: 500 });

  const results = (data || []).map((r:any) => ({
    id: r.taxon_id,
    display: r.is_scientific ? `${r.name} (${r.taxon.rank})` : `${r.name} – ${r.taxon.canonical_name}`,
  }));

  return NextResponse.json(results);
}
