import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
);

export async function GET(_: Request, { params }: { params: Promise<{ id: string }> }) {
  const { id: idParam } = await params;
  const id = Number(idParam);

  const [{ data: tx }, { data: names }, { data: status }, { data: pics }] = await Promise.all([
    supabase.from("taxon").select("*").eq("id", id).single(),
    supabase.from("taxon_name").select("*").eq("taxon_id", id),
    supabase.from("taxon_status").select("*").eq("taxon_id", id).limit(1),
    supabase.from("media").select("*").eq("taxon_id", id).limit(8),
  ]);

  return NextResponse.json({ taxon: tx, names, status: status?.[0] || null, media: pics || [] });
}